<?php

namespace Drupal\advban;

/**
 * Advban helper.
 */
class AdvbanHelper {

  const ADVBAN_NEVER = 'never';

}
