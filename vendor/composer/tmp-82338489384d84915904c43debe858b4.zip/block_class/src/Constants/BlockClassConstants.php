<?php

namespace Drupal\block_class\Constants;

/**
 * Block Class Constants.
 */
class BlockClassConstants {

  /**
   * Block Class Permission.
   */
  const BLOCK_CLASS_PERMISSION = 'administer block classes';

}
